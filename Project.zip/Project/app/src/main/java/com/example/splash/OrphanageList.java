package com.example.splash;

public class OrphanageList {
    public static String[] getOrphanageList() {
        return new String[] {
                "Sadhana Institute for Mentally Retarded\n" +
                        "Industrial Development Area, Nacharam,\n" +
                        "Uppal Kalan, Telangana 500076", "BBS Devnar School For The Blind\n" +
                "1-10-122 to 1,Mayur Marg,\n" +
                "Begumpet, Hyderabad-500016", "Tara Ashram (Street Children)\n" +
                "Secunderabad, Near St. Patricks School", "Forum For Street Children\n" +
                "(M.C.H. Library Building) 1st Floor,\n" +
                "Bible House, R.P Road,\n" +
                "Secunderabad H.O., Hyderabad 500003", "Aman Vedika\n" +
                "Near Musheerabad Police Station,\n" +
                "Secunderabad","Don Bosco- Navajeevan\n" +
                "H. No: 6-2-323, near St. Philomena School,\n" +
                "New BhoiGuda , Secunderbad", "Don Bosco Navajeevan Child Care Centre\n" +
                "11-6-472, Bazar Ghat, Nampally\n" +
                "Hyderabad, Telangana", "Hyderabad Council of Human Welfare\n" +
                "Essamiya Bazaar, Koti, Hyderabad, Telangana", "Ashray Akruti\n" +
                "8-3-1027/A2, Srinagar Colony\n" +
                "Srinagar Colony, Hyderabad-500873","Shanti Nilayam\n" +
                "Bakaram Jagir, Vikarabad Road,\n" +
                "Before Chilkur X Roads, Ranga Reddy Dist.\n" +
                "Hyderabad, Telangana"+"Anurag Human Services\n" +
                "No.9-4-136/B, Bentoubavdi, Anurag Colony,\n" +
                "Toli Chowki, Hyderabad, Telangana 500008","Aadarana home for boys\n" +
                "#16-2-738/4/5/12, Road No 2,\n" +
                "SBH Bank Colony, Asmangadh,\n" +
                "Near TV Tower, Malakpet,\n" +
                "Hyderabad, Andhra Pradesh – 500 036.","Kasturba Gandhi National Memorial Trust\n" +
                "Himagiri Nagar Colony Rd,\n" +
                "West End Colony, Bandlaguda Jagir,\n" +
                "Hyderabad, 500031", "Amanvedika Snehghar Boys Home\n" +
                "Opp MRO Office ,\n" +
                "Vijaynagar colony,\n" +
                "Masabtank,\n" +
                "Hyderabad", "Society for Health, Education and\n" +
                "Economic Progress\n" +
                "H.No – 8-4-550/88, Natraj Nagar,\n" +
                "Near A G Colony, ESI, Erragadda,\n" +
                "Hyderabad – 500018", "Mahima Ministries\n" +
                "NTR Nagar Colony, Sreedevi Theatre Road,\n" +
                "Ameenpur, Chandanagar", "Amanvedika Snehghar Boys Home\n" +
                "Adaiah Nagar Govt School,\n" +
                "Near Bible House,\n" +
                "Secunderabad", "Arunodaya Trust\n" +
                "D No 1-47, Road No 2,\n" +
                "Ex Service Men Colony, Balaji Nagar,\n" +
                "Secunderabad – 500003", "Mathuru Devo Bhava Charitable Trust\n" +
                "4-33-254, Srinivasa Nagar,\n" +
                "Near Ambedkar Statue, Jagadgirigutta,\n" +
                "Hyderabad – 500037", "Kinnera Welfare Society\n" +
                "12-2-717/A/9, Padmanabha Nagar,\n" +
                "Rethi Bowli Ring Road, Mehdipatnam,\n" +
                "Near Sai Baba Temple, Hyderabad – 500028", "Manchikalalu Organisation\n" +
                "3-41-112, Plot No – 14/7,\n" +
                "West Maredpally, Near Police Station,\n" +
                "Hyderabad – 500026", "Aadarana – Centre for orphans\n" +
                "and needy children\n" +
                "Plot NO – 74, Sri Krishna Nagar,\n" +
                "Behind Sai Function Hall,\n" +
                "Saroor Nagar", "Auxilium Nava Jeevan Home\n" +
                "H.No : 6-4-493, Opp Gandhi Hospotal,\n" +
                "Krishna Nagar Colony, Bholkpur,\n" +
                "Musheerabad, Secunderabad – 500080", "Don Bosco Navajeevan Child Care Centre\n" +
                "11-6-472, Bazar Ghat, Nampally\n" +
                "Hyderabad, Telangana", "Amma Foundation\n" +
                "16-1-28/13/2, Balaji Sweet House, 2nd Flr,\n" +
                "Saidabad, Hyderabad – 500059", "Mother India Orphanage Home\n" +
                "16-86/2, Venkataiah Panthulu\n" +
                "Nilayam, Malkajgiri, Near New Mirjalguda", "Agape Children’s Home\n" +
                "9-109/110/110,\n" +
                "Puspa Rajayya Nilayam,\n" +
                "Near Venkatesheara Swamy\n" +
                "Temple, Uppal"+"Sankalp Foundation\n" +
                "Plot No 1508\n" +
                "Papireddy Colony,\n" +
                "Chanda Nagar,\n" +
                "Opp: Chanda Nagar Railway Station, Uppal"
        };
    }
}
